--- Password for all users: 'star trek'
INSERT INTO users(
            "login", "password", role_id, email, "first", "last", locale,active,cookie_string, script_key)
    VALUES ('kirk','9651cbc7c0b5fb1a81f2858a07813c82',8,
            'james.tiberius.kirk@roddenberry.com','James Tiberius','Kirk','en_GB',1,'1234567890','DEVKEY-kirk');

INSERT INTO users(
            "login", "password", role_id, email, "first", "last", locale,active,cookie_string, script_key)
    VALUES ('spock','9651cbc7c0b5fb1a81f2858a07813c82',9,
            'mr.spock@roddenberry.com','Mr','Spock','it_IT',1,'1234567891','DEVKEY-spock');

INSERT INTO users(
            "login", "password", role_id, email, "first", "last", locale,active,cookie_string, script_key)
    VALUES ('maccoy','9651cbc7c0b5fb1a81f2858a07813c82',6,
            'leonard.mccoy@Roddenberry.com','Leonard H','McCoy','en_GB',1,'1234567892','DEVKEY-mccoy');


INSERT INTO users(
            "login", "password", role_id, email, "first", "last", locale,active,cookie_string, script_key)
    VALUES ('chekov','9651cbc7c0b5fb1a81f2858a07813c82',6,
            'pavel.chekov@roddenberry.com','Pavel','Chekov','en_GB',1,'1234567893','DEVKEY-chekov');
 
INSERT INTO users(
            "login", "password", role_id, email, "first", "last", locale,active,cookie_string, script_key)
    VALUES ('scott','9651cbc7c0b5fb1a81f2858a07813c82',8,
            'lt.commander.scott.chekov@roddenberry.com','Lt. Commander','Scott','en_GB',1,'1234567894','DEVKEY-scott');
